#!/usr/bin/env python3
from utils.beginning import beginning

if __name__ == "__main__":
    beginning()
    

