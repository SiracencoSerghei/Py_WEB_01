def good_bye():
        """Bid farewell to the user.

        Returns:
            str: A farewell message.
        """
        print("Good bye!")
        return "Good bye!"
